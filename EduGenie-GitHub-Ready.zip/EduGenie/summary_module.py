from gemini_client import generate_text


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the educational text below for quick revision.

TEXT:
{text}

Requirements:
- Preserve the main facts and ideas.
- Remove repetition and low-value detail.
- Use a concise heading and bullet points.
- Do not add information that is not supported by the input.
"""
    return generate_text(
        prompt,
        system_instruction="You are an educational summarization assistant.",
    )
