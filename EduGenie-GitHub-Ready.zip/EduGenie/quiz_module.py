from typing import List

from pydantic import BaseModel, Field, field_validator

from gemini_client import generate_structured


class QuizQuestion(BaseModel):
    question: str
    options: List[str] = Field(min_length=4, max_length=4)
    correct_answer: str
    explanation: str

    @field_validator("correct_answer")
    @classmethod
    def answer_must_be_an_option(cls, value, info):
        options = info.data.get("options", [])
        if options and value not in options:
            raise ValueError("correct_answer must exactly match one option.")
        return value


class QuizResponse(BaseModel):
    questions: List[QuizQuestion] = Field(min_length=3, max_length=3)


def generate_quiz(passage: str) -> QuizResponse:
    prompt = f"""
Create exactly three multiple-choice questions from the passage below.

PASSAGE:
{passage}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- Only one option is correct.
- correct_answer must exactly equal the correct option text.
- Include a brief explanation for each answer.
- Questions must be answerable from the passage.
"""
    return generate_structured(prompt, QuizResponse)
