from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

from qna import answer_question
from explanation_module import explain_topic
from quiz_module import generate_quiz, QuizResponse
from summary_module import summarize_text
from learning_path import get_learning_recommendations

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(
    title="EduGenie",
    description="Google Gemini powered learning assistant",
    version="1.0.1",
)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


class TextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=50000)


class QARequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=10000)


class QuizRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=30000)


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"request": request},
    )


@app.get("/health")
async def health():
    return {"status": "ok", "service": "EduGenie"}


@app.post("/qa")
async def qa(payload: QARequest):
    try:
        result = answer_question(payload.question)
        return {"success": True, "result": result}
    except Exception as exc:
        return JSONResponse(
            status_code=502,
            content={"success": False, "error": str(exc)},
        )


@app.post("/explain")
async def explain(payload: TextRequest):
    try:
        result = explain_topic(payload.text)
        return {"success": True, "result": result}
    except Exception as exc:
        return JSONResponse(
            status_code=502,
            content={"success": False, "error": str(exc)},
        )


@app.post("/quiz")
async def quiz(payload: QuizRequest):
    try:
        result: QuizResponse = generate_quiz(payload.text)
        return {"success": True, "result": result.model_dump()}
    except Exception as exc:
        return JSONResponse(
            status_code=502,
            content={"success": False, "error": str(exc)},
        )


@app.post("/summarize")
async def summarize(payload: TextRequest):
    try:
        result = summarize_text(payload.text)
        return {"success": True, "result": result}
    except Exception as exc:
        return JSONResponse(
            status_code=502,
            content={"success": False, "error": str(exc)},
        )


@app.post("/learn/recommendations")
async def learn(payload: TextRequest):
    try:
        result = get_learning_recommendations(payload.text)
        return {"success": True, "result": result}
    except Exception as exc:
        return JSONResponse(
            status_code=502,
            content={"success": False, "error": str(exc)},
        )
