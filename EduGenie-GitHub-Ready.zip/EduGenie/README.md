# EduGenie — Gemini Learning Assistant

EduGenie is a lightweight AI-powered educational assistant built with **FastAPI**, **HTML/CSS**, and **Google Gemini**.

## Features

- AI question answering
- Beginner-friendly explanations
- MCQ quiz generation
- Text summarization
- Personalized learning-path recommendations
- FastAPI REST API
- Responsive web interface

## Project Structure

```text
EduGenie/
├── main.py
├── config.py
├── gemini_client.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── tests/
    └── test_api.py
```

## Run Locally

### 1. Clone the repository

```bash
git clone <your-github-repository-url>
cd EduGenie
```

### 2. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env` and add your own Google AI Studio API key.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

macOS/Linux:

```bash
cp .env.example .env
```

**Never commit `.env` or a real API key to GitHub.**

### 5. Start the application

```bash
uvicorn main:app --reload
```

Open:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs

### 6. Run tests

```bash
pytest
```

## Optional Local Explanation Model

The local explanation model is disabled by default. Enable it only after installing compatible `transformers`, `torch`, and `sentencepiece` dependencies.

## GitHub Upload

This package intentionally excludes:

- `.venv/`
- Python cache files
- pytest cache
- IDE-specific files
- `.env` secrets

Create a Git repository from the `EduGenie` folder and push it to GitHub:

```bash
git init
git add .
git commit -m "Initial EduGenie project"
git branch -M main
git remote add origin <your-github-repository-url>
git push -u origin main
```

## License

Add the license you want to use for your project before publishing it publicly.
