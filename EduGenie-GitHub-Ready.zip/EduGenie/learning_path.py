from gemini_client import generate_text


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""
Create a personalized learning path for:

{topic}

Organize it from beginner to advanced. Include:
- Stage and difficulty
- Concepts to learn
- Suggested practice
- A realistic timeline
- Types of resources to use (videos, articles, books, documentation)
- A short milestone/checkpoint for each stage

Do not fabricate specific URLs. Give resource types or well-known resource names
only when you are confident they are real.
"""
    return generate_text(
        prompt,
        system_instruction=(
            "You are a curriculum designer who creates practical, "
            "progressive learning plans for self-learners."
        ),
    )
