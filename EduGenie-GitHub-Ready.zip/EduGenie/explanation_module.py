from functools import lru_cache

from config import get_settings
from gemini_client import generate_text


@lru_cache(maxsize=1)
def _load_local_pipeline():
    settings = get_settings()
    if not settings.use_local_explanation:
        return None

    try:
        from transformers import pipeline
        return pipeline(
            "text2text-generation",
            model=settings.local_explanation_model,
            device=-1,
        )
    except Exception:
        return None


def _local_explanation(topic: str) -> str | None:
    pipe = _load_local_pipeline()
    if pipe is None:
        return None

    prompt = (
        "Explain the following topic to a beginner in simple language. "
        "Use a short definition, an intuitive example, and 3 key points.\n\n"
        f"Topic: {topic}"
    )
    result = pipe(prompt, max_new_tokens=220, do_sample=False)
    if result and result[0].get("generated_text"):
        return result[0]["generated_text"].strip()
    return None


def explain_topic(topic: str) -> str:
    local = _local_explanation(topic)
    if local:
        return local

    prompt = f"""
Explain this educational topic for a beginner:

{topic}

Structure:
1. Simple definition
2. Intuitive explanation
3. Everyday or practical example
4. Three key takeaways

Keep the language clear and avoid unnecessary jargon.
"""
    return generate_text(
        prompt,
        system_instruction="You simplify complex educational concepts without losing accuracy.",
    )
