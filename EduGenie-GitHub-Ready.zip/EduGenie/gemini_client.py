from functools import lru_cache
from typing import Type, TypeVar

from google import genai
from google.genai import types
from pydantic import BaseModel

from config import get_settings

T = TypeVar("T", bound=BaseModel)


@lru_cache(maxsize=1)
def get_client():
    settings = get_settings()
    if not settings.gemini_api_key:
        raise RuntimeError(
            "GEMINI_API_KEY is not configured. Create a .env file in the project root "
            "and add your Google AI Studio API key."
        )
    return genai.Client(api_key=settings.gemini_api_key)


def generate_text(prompt: str, *, system_instruction: str | None = None) -> str:
    settings = get_settings()
    client = get_client()

    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            system_instruction=system_instruction,
            temperature=settings.temperature,
            max_output_tokens=settings.max_output_tokens,
        ),
    )

    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned an empty response.")
    return text.strip()


def generate_structured(prompt: str, schema: Type[T]) -> T:
    settings = get_settings()
    client = get_client()

    response = client.models.generate_content(
        model=settings.gemini_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=settings.temperature,
            max_output_tokens=settings.max_output_tokens,
            response_mime_type="application/json",
            response_schema=schema,
        ),
    )

    parsed = getattr(response, "parsed", None)
    if isinstance(parsed, schema):
        return parsed
    if parsed is not None:
        return schema.model_validate(parsed)

    text = getattr(response, "text", None)
    if not text:
        raise RuntimeError("Gemini returned no structured output.")
    return schema.model_validate_json(text)
